<?php
include 'address.php';
include 'xmlrpc.inc';

if (isset($_POST['func'])) {
  $func = $_POST['func'];
} else {
  $func = 'sin(x)';
}

if (isset($_POST['min'])) {
  $min = $_POST['min'];
} else {
  $min = -1.0;
}

if (isset($_POST['max'])) {
  $max = $_POST['max'];
} else {
  $max = 1.0;
}

// Make an object to represent our server.
$server = new xmlrpc_client('/xmlrpc/rpc_server.php', $host, $port);

// Send a message to the server.
$message = new xmlrpcmsg('sample.math_equation',
                         array(new xmlrpcval($min, 'double'),
                               new xmlrpcval($max, 'double'),
                               new xmlrpcval($func, 'string'),
                               new xmlrpcval('x', 'string')
                         ));

$result = $server->send($message);

// Process the response.
if (!$result) {

  echo '<html><head><title>XML-RPC PHP Equation Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Equation Demo</h1>';
  echo "<p>Could not connect to HTTP server.</p>";
  echo '</body></html>';

} elseif ($result->faultCode()) {

  echo '<html><head>
        <title>XML-RPC PHP Equation Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Equation Demo</h1>';
  echo "<p>XML-RPC Fault #" . $result->faultCode() . ": " . $result->faultString();
  echo ' ', $func, '</p>';
  echo '</body></html>';

} else {

  echo '<html><head>
        <title>XML-RPC PHP Equation Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Equation Demo</h1>';

  $struct = $result->value();

  // ������� ������ �������?
  $count = $struct->structmem('count')->scalarval();

  if ($count > 0) {
    echo '<p>', $count, " ������:</p>\n";
    // ��������� �����
    for($i=0; $i<$count; $i++) {
      $x = $struct->structmem('x' . $i)->scalarval();
      echo '<p>x', $i+1, '=', $x, "</p>\n";
    }
  } else {
    echo '<p>������ ���</p>';
  }

  echo '</body></html>';
}

?>