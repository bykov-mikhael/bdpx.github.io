<?php
include 'address.php';
include 'xmlrpc.inc';

if (isset($_POST['func'])) {
  $func = $_POST['func'];
} else {
  $func = 'sin(x)';
}

if (isset($_POST['min'])) {
  $min = $_POST['min'];
} else {
  $min = -1.0;
}

if (isset($_POST['max'])) {
  $max = $_POST['max'];
} else {
  $max = 1.0;
}

if (isset($_POST['wgt'])) {
  $wgt = $_POST['wgt'];
} else {
  $wgt = 800;
}
if (isset($_POST['hgt'])) {
  $hgt = $_POST['hgt'];
} else {
  $hgt = 600;
}

// Make an object to represent our server.
$server = new xmlrpc_client('/xmlrpc/rpc_server.php', $host, $port);

// Send a message to the server.
$message = new xmlrpcmsg('sample.math_graphic',
                         array(new xmlrpcval($min, 'double'),
                               new xmlrpcval($max, 'double'),
                               new xmlrpcval($wgt, 'int'),
                               new xmlrpcval($hgt, 'int'),
                               new xmlrpcval($func, 'string'),
                               new xmlrpcval('x', 'string')
                         ));

$result = $server->send($message);

// Process the response.
if (!$result) {

  echo '<html><head><title>XML-RPC PHP Graphic Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Graphic Demo</h1>';
  echo "<p>Could not connect to HTTP server.</p>";
  echo '</body></html>';

} elseif ($result->faultCode()) {
  echo '<html><head>
        <title>XML-RPC PHP Graphic Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Graphic Demo</h1>';
  echo "<p>XML-RPC Fault #" . $result->faultCode() . ": " . $result->faultString();
  echo ' ', $func, '</p>';
  echo '</body></html>';

} else if (0) {

  echo '<html><head><title>XML-RPC PHP Graphic Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Graphic Demo</h1>';
  $struct = $result->value();

  $fmin = $struct->structmem('fmin')->scalarval();
  $fmax = $struct->structmem('fmax')->scalarval();
  $func = $struct->structmem('func')->scalarval();
  $name = $struct->structmem('name')->scalarval();
  $data = $struct->structmem('data')->scalarval();

  echo "<p>fmin: " . $fmin . ", fmax: " . $fmax . ' F(' . $name . ') = ' . $func . ' ' . strlen($data). "</p>";
  echo $data;
  echo '</body></html>';

} else {

  $struct = $result->value();

  $fmin = $struct->structmem('fmin')->scalarval();
  $fmax = $struct->structmem('fmax')->scalarval();
  $data = $struct->structmem('data')->scalarval();

  // ���塞 �⠭����� ��������� HTTP (text/html) �� ��㣮� ⨯ ���⥭� (image/gif)
  header("Content-type: image/png");

  // �⤠�� ������ ����� ��㭪�
  echo $data;
}

?>