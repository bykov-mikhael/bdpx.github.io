<?php
include 'address.php';
include 'xmlrpc.inc';

if (isset($_POST['func'])) {
  $func = $_POST['func'];
} else {
  $func = 'sin(x)';
}

if (isset($_POST['min'])) {
  $min = $_POST['min'];
} else {
  $min = -1.0;
}

if (isset($_POST['max'])) {
  $max = $_POST['max'];
} else {
  $max = 1.0;
}

// Make an object to represent our server.
$server = new xmlrpc_client('/xmlrpc/rpc_server.php', $host, $port);

// Send a message to the server.
$message = new xmlrpcmsg('sample.math_integral',
                         array(new xmlrpcval($min, 'double'),
                               new xmlrpcval($max, 'double'),
                               new xmlrpcval($func, 'string'),
                               new xmlrpcval('x', 'string')
                         ));

$result = $server->send($message);

// Process the response.
if (!$result) {

  echo '<html><head><title>XML-RPC PHP Integral Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Integral Demo</h1>';
  echo "<p>Could not connect to HTTP server.</p>";
  echo '</body></html>';

} elseif ($result->faultCode()) {

  echo '<html><head>
        <title>XML-RPC PHP Integral Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Integral Demo</h1>';
  echo "<p>XML-RPC Fault #" . $result->faultCode() . ": " . $result->faultString();
  echo ' ', $func, '</p>';
  echo '</body></html>';

} else {

  echo '<html><head>
        <title>XML-RPC PHP Integral Demo</title>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        <meta name="language" content="ru">
        </head><body><h1>XML-RPC PHP Integral Demo</h1>';
  $struct = $result->value();

  $fmin = $struct->structmem('fmin')->scalarval();
  $fmax = $struct->structmem('fmax')->scalarval();
  $func = $struct->structmem('func')->scalarval();
  $name = $struct->structmem('name')->scalarval();
  $data = $struct->structmem('data')->scalarval();

  echo "<p>F<sub>min</sub> = " . $fmin . ", F<sub>max</sub> = " . $fmax . ', F(' . $name . ') = ' . $func . "</p>";
  echo "<p> ������������ �������� �� ", $min, " �� ", $max, " �����: ", $data, "</p>";

  echo '</body></html>';

}

?>