
#include <stdio.h>
#include <windows.h>

#include "common.h"

int main(int argc, char **argv)
{
  char          *map_data;
  HANDLE        hMapFile;


  /* open existing mapzone */
  hMapFile = OpenFileMapping(FILE_MAP_READ, FALSE, MapName);
  if (hMapFile == NULL) {
    printf("Can't open mapzone\n");
    return;
  }

  /* lock mapzone in current process address space */
  map_data = (char *) MapViewOfFile(hMapFile, FILE_MAP_READ, 0, 0, MAPSIZE);
  if(map_data == NULL) {
    CloseHandle(hMapFile);
    printf("Can't lock mapzone %p.\n", hMapFile);
    return;
  }

  /* get info from mapzone */
  printf("Slave report data from map: %s\n", map_data);

  /* we not need later mapzone - unlock & free it */
  UnmapViewOfFile(map_data);
  CloseHandle(hMapFile);

  return(0);
}

