
#include <stdio.h>
#include <process.h>
#include <windows.h>

#include "common.h"

int main(int argc, char **argv)
{
  int         result;
  HANDLE      hMapFile;
  char        *map_data;

  /* create mapzone handle */
  hMapFile = CreateFileMapping((HANDLE)0xFFFFFFFF, NULL, PAGE_READWRITE, 0, MAPSIZE, MapName);
  if (hMapFile != NULL && GetLastError() == ERROR_ALREADY_EXISTS) {
    printf("FileMapping handle %p exist.\n", hMapFile);
    CloseHandle(hMapFile);
    return;
  }

  if(hMapFile == NULL) {
    printf("FileMapping handle not created.\n");
    return;
  }

  /* lock mapzone in current process address space */
  map_data = (char *) MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, MAPSIZE);
  if(map_data == NULL) {
    printf("Can't lock mapzone.\n");
    return;
  }

  /* write data in mapzone */
  sprintf(map_data, "123456789 vsyaki bred 987654321");

  /* start slave process and wait it's termination */
  result = _spawnlp(P_WAIT, "slave.exe", "slave.exe", "-x", NULL);

  /* destroy mapzone */
  UnmapViewOfFile(map_data);
  CloseHandle(hMapFile);

  return(0);
}

