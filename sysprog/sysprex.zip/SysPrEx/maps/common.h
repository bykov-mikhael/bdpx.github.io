
#define MAPSIZE (16 * 4 * 1024) /* 16 pages */
#define MapName "MyMapZoneName"
