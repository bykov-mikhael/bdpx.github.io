
#include <stdio.h>
#include <windows.h>


int main(int argc, char **argv)
{
  char *buf;
  DWORD dwInitialSize = 1024 * 32;
  DWORD dwMaximumSize = 1024 * 1024;

  HANDLE MyHeap;

  MyHeap = HeapCreate(HEAP_NO_SERIALIZE, dwInitialSize, dwMaximumSize);	
  if (MyHeap == NULL) {
    printf("Can't create private heap\n");
    exit(666);
  }

  buf = (char *) HeapAlloc(MyHeap, HEAP_NO_SERIALIZE | HEAP_ZERO_MEMORY, 1024 * sizeof(char));	
  if (buf == NULL) {
    printf("Can't allocate memory block\n");
    exit(666);
  }

  HeapFree(MyHeap, HEAP_NO_SERIALIZE, buf);

  HeapDestroy(MyHeap);

  printf("All is OK!\n");
  return(0);
}

