
#include <stdio.h>
#include <windows.h>

DWORD TLS_Slot;

//__declspec(dllexport)
int __stdcall DllFunc(int x, int y)
{
  char *ptr;
  ptr = (char *)TlsGetValue(TLS_Slot);
  printf("%s\n", ptr);
  printf("DllFunc called: %d %d\n", x, y);
  return (x+y);
}

BOOL WINAPI
DllEntryPoint(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
  BOOL ret;
  char *ptr;

  switch (fdwReason) {

    case DLL_PROCESS_ATTACH:
      printf("process attach ");
      TLS_Slot = TlsAlloc();
      printf("TLS_Slot=%u\n", TLS_Slot);
//      break;
    case DLL_THREAD_ATTACH:
      printf("thread attach TLS_Slot=%u\n", TLS_Slot);
      ptr = (char *) malloc (1024 * sizeof(char));
      sprintf(ptr, "%s", "this is private string for thread");
      ret = TlsSetValue(TLS_Slot, (LPVOID)ptr);
      break;

    case DLL_PROCESS_DETACH:
      printf("process detach\n");
      TlsFree(TLS_Slot);
//      break;
    case DLL_THREAD_DETACH:
      printf("thread detach ");
      ptr = (char *)TlsGetValue(TLS_Slot);
      free(ptr);
      break;
  }

  return (TRUE);
}
