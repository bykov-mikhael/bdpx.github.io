
#include <stdio.h>

extern int __stdcall DllFunc(int x, int y);

int main(int argc, char **argv)
{
  int ret;

  ret = DllFunc(9, 12);
  printf("ret=%d\n", ret);

  ret = DllFunc(9, 10);
  printf("ret=%d\n", ret);

  return (0);
}
