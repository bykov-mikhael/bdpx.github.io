
#include <stdio.h>
#include <windows.h>

typedef int __stdcall (*DllFuncType)(int x, int y);


int main(int argc, char **argv)
{
  int ret;
  DllFuncType DllFunc;
  HINSTANCE lib;

  lib = LoadLibrary("MyDll.dll");
  if (lib == NULL) {
    printf("Can't load library\n");
    exit(666);
  }

  DllFunc = (DllFuncType) GetProcAddress(lib, "DllFunc");
  if (DllFunc == NULL) {
    printf("Can't find entry point\n");
    exit(666);
  }

  ret = DllFunc(9, 12);
  printf("ret=%d\n", ret);

  ret = DllFunc(9, 10);
  printf("ret=%d\n", ret);

  FreeLibrary(lib);
  return (0);
}
