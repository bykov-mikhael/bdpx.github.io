
#include <windows.h>
#include <stdio.h>

int main(int argc, char **argv)
{
  PROCESS_INFORMATION  pi;
  STARTUPINFO  si;
  int i;
  char cmdline[256];

  si.cb			= sizeof(si);
  si.lpReserved		= NULL; 
  si.lpDesktop		= NULL; 
  si.lpTitle		= "my process"; 
  si.dwX		= 10; 
  si.dwY		= 10; 
  si.dwXSize		= 800; 
  si.dwYSize		= 300; 
  si.dwXCountChars	= 80; 
  si.dwYCountChars	= 100; 
  si.dwFillAttribute	= FOREGROUND_RED | BACKGROUND_RED | BACKGROUND_GREEN; 
  si.dwFlags		= STARTF_USEFILLATTRIBUTE|STARTF_USEPOSITION|STARTF_USESIZE; 
  si.wShowWindow	= SW_SHOW; 
  si.cbReserved2	= 0; 
  si.lpReserved2	= NULL; 
  si.hStdInput		= NULL; 
  si.hStdOutput		= NULL; 
  si.hStdError		= NULL; 

  if (argc < 2) {
    printf("I am parent\n");
    for(i=0; i<3; i++) {
      sprintf(cmdline, "%s %d", argv[0], i);
      CreateProcess(argv[0], cmdline, NULL, NULL, TRUE,
            CREATE_NEW_CONSOLE|NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi);
      CloseHandle(pi.hProcess);
      CloseHandle(pi.hThread);
    }
  } else {
    printf("I am slave number %s\n", argv[1]);
  }
  getch();
  return 0;
}
