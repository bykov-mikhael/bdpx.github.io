
#include <stdlib.h>
#include <stdio.h>

#include <windows.h>
#include <winnt.h>

LONG CALLBACK MyUnhandledExceptionFilter(EXCEPTION_POINTERS *ExceptionInfo)
{
  DWORD               i;
  PCONTEXT            Context;
  PEXCEPTION_RECORD   ExcRecord;

  printf("MyUnhandledExceptionFilter called\n");

  ExcRecord = ExceptionInfo->ExceptionRecord;

  printf("ExceptionCode =%08x\n", ExcRecord->ExceptionCode);

  switch (ExcRecord->ExceptionCode) {
    case EXCEPTION_ACCESS_VIOLATION:
      printf("Access violation\n");
      break;
    case EXCEPTION_DATATYPE_MISALIGNMENT: break;
    case EXCEPTION_BREAKPOINT: break;
    case EXCEPTION_SINGLE_STEP: break;
    case EXCEPTION_ARRAY_BOUNDS_EXCEEDED: break;
    case EXCEPTION_FLT_DENORMAL_OPERAND: break;
    case EXCEPTION_FLT_DIVIDE_BY_ZERO: break;
    case EXCEPTION_FLT_INEXACT_RESULT: break;
    case EXCEPTION_FLT_INVALID_OPERATION: break;
    case EXCEPTION_FLT_OVERFLOW: break;
    case EXCEPTION_FLT_STACK_CHECK: break;
    case EXCEPTION_FLT_UNDERFLOW: break;
    case EXCEPTION_INT_DIVIDE_BY_ZERO: break;
    case EXCEPTION_INT_OVERFLOW: break;
    case EXCEPTION_PRIV_INSTRUCTION: break;
    case EXCEPTION_IN_PAGE_ERROR: break;
    case EXCEPTION_ILLEGAL_INSTRUCTION: break;
    case EXCEPTION_NONCONTINUABLE_EXCEPTION: break;
    case EXCEPTION_STACK_OVERFLOW: break;
    case EXCEPTION_INVALID_DISPOSITION: break;
    case EXCEPTION_GUARD_PAGE: break;
    case EXCEPTION_INVALID_HANDLE: break;
    /* this list is not full! */
    default:
      printf("Unknown exception code: %d", ExcRecord->ExceptionCode);
  }

  printf("ExceptionFlags =%08x\n", ExcRecord->ExceptionFlags);
  printf("ExceptionRecord (chain) =%p\n", ExcRecord->ExceptionRecord);
  printf("ExceptionAddress =%p\n", ExcRecord->ExceptionAddress);
  printf("NumberParameters =%d\n", ExcRecord->NumberParameters);

// EXCEPTION_MAXIMUM_PARAMETERS
  for(i=0; i<ExcRecord->NumberParameters; i++)
    printf("Param[%d] =%p\n", i, ExcRecord->ExceptionInformation[i]);

  Context = ExceptionInfo->ContextRecord;

  printf("SegGs =%08x\n", Context->SegGs);
  printf("SegFs =%08x\n", Context->SegFs);
  printf("SegEs =%08x\n", Context->SegEs);
  printf("SegDs =%08x\n", Context->SegDs);

    //
    // This section is specified/returned if the
    // ContextFlags word contians the flag CONTEXT_INTEGER.
    //

  printf("Edi   =%08x\n", Context->Edi);
  printf("Esi   =%08x\n", Context->Esi);
  printf("Ebx   =%08x\n", Context->Ebx);
  printf("Edx   =%08x\n", Context->Edx);
  printf("Ecx   =%08x\n", Context->Ecx);
  printf("Eax   =%08x\n", Context->Eax);

    //
    // This section is specified/returned if the
    // ContextFlags word contians the flag CONTEXT_CONTROL.
    //

  printf("Ebp   =%08x\n", Context->Ebp);
  printf("Eip   =%08x\n", Context->Eip);
  printf("SegCs =%08x\n", Context->SegCs);              // MUST BE SANITIZED
  printf("EFlags=%08x\n", Context->EFlags);             // MUST BE SANITIZED
  printf("Esp   =%08x\n", Context->Esp);
  printf("SegSs =%08x\n", Context->SegSs);

  /* Popup messagebox */
  return (EXCEPTION_CONTINUE_SEARCH);

  /* Terminate without system messagebox */
  return (EXCEPTION_EXECUTE_HANDLER);

  /* danger! May be dead loop. */
  return (EXCEPTION_CONTINUE_EXECUTION);
}


void CrashFunc(int x, int y)
{
  /* write to cosmos */
  ((int*)0x9876543210)[4] = x+y;
}


int main(void)
{
  LPTOP_LEVEL_EXCEPTION_FILTER prev;

  prev = SetUnhandledExceptionFilter(MyUnhandledExceptionFilter);

  /* Now test crashing */
  CrashFunc(345, 567);

  return (0);
}
