
#include <stdio.h>
#include <process.h>
#include <windows.h>

#define MAPSIZE (16 * 4 * 1024) /* 16 pages */

int main(int argc, char **argv)
{
  int         result;
  HANDLE      hMapFile, hFile;
  char        *map_data;

  hFile = CreateFile("mydata.dat", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ,
                     NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

  /* create mapzone handle */
  hMapFile = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, MAPSIZE, "MapName");
  if (hMapFile != NULL && GetLastError() == ERROR_ALREADY_EXISTS) {
    printf("FileMapping handle %p exist.\n", hMapFile);
    CloseHandle(hMapFile);
    return;
  }

  if(hMapFile == NULL) {
    printf("FileMapping handle not created.\n");
    return;
  }

  /* lock mapzone in process address space */
  map_data = (char *) MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, MAPSIZE);
  if(map_data == NULL) {
    printf("Can't lock mapzone.\n");
    return;
  }

  /* write data in mapzone */
  sprintf(map_data, "123456789 vsyaki bred 987654321");

  /* unmap mapzone, close file */
  UnmapViewOfFile(map_data);
  CloseHandle(hMapFile);
  CloseHandle(hFile);

  return(0);
}

