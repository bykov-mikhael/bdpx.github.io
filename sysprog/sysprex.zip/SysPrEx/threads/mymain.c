
#include <stdio.h>
#include <process.h>
#include <windows.h>

typedef int __stdcall (*DllFuncType)(int x, int y);
typedef void __stdcall (*SetThreadPrivateDataFunc)(const char *str);

DllFuncType DllFunc;
SetThreadPrivateDataFunc SetThreadPrivateData;

void ThreadFunc(void *param)
{
  int ret, i;
  char buf[256];

  i = (int)param;

  sprintf(buf, "I am thread with parameter %d", i);

  SetThreadPrivateData(buf);

  ret = DllFunc(9, i);
}


int main(int argc, char **argv)
{
  int i, ret;
  HINSTANCE lib;

  lib = LoadLibrary("MyDll.dll");
  if (lib == NULL) {
    printf("Can't load library\n");
    exit(666);
  }

  DllFunc = (DllFuncType) GetProcAddress(lib, "DllFunc");
  if (DllFunc == NULL) {
    printf("Can't find entry point <DllFunc>\n");
    exit(666);
  }

  SetThreadPrivateData = (SetThreadPrivateDataFunc) GetProcAddress(lib, "SetThreadPrivateData");
  if (DllFunc == NULL) {
    printf("Can't find entry point <SetThreadPrivateData>\n");
    exit(666);
  }

  ret = DllFunc(9, 12);

  for(i=0; i<8; i++)
    _beginthread(ThreadFunc, 64 * 1024, (void*)i);

  ret = DllFunc(9, 10);

  Sleep(1000);

  FreeLibrary(lib);
  return (0);
}
