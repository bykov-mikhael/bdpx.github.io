
#include <stdio.h>
#include <windows.h>

DWORD TLS_Slot;

void __stdcall SetThreadPrivateData(const char *str)
{
  sprintf((char *)TlsGetValue(TLS_Slot), "%s", str);
}

char *__stdcall GetThreadPrivateData(const char *str)
{
  return (char *)TlsGetValue(TLS_Slot);
}

//__declspec(dllexport)
int __stdcall DllFunc(int x, int y)
{
  char *ptr;
  ptr = (char *)TlsGetValue(TLS_Slot);
  printf("%s\n", ptr);
  printf("DllFunc called: %d %d\n", x, y);
  return (x+y);
}


BOOL WINAPI DllEntryPoint(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
  BOOL ret;
  char *ptr;

  switch (fdwReason) {

    case DLL_PROCESS_ATTACH:
      TLS_Slot = TlsAlloc();
      printf("process attach TLS_Slot=%u\n", TLS_Slot);
//      break;
    case DLL_THREAD_ATTACH:
      printf("thread have attached TLS_Slot=%u\n", TLS_Slot);
      ptr = (char *) malloc (1024 * sizeof(char));
      sprintf(ptr, "%s", "this is private string for thread");
      ret = TlsSetValue(TLS_Slot, (LPVOID)ptr);
      break;

    case DLL_PROCESS_DETACH:
      printf("process detach\n");
      TlsFree(TLS_Slot);
//      break;
    case DLL_THREAD_DETACH:
      printf("thread detach\n");
      ptr = (char *)TlsGetValue(TLS_Slot);
      free(ptr);
      break;
  }

  return (TRUE);
}
