
#include <stdio.h>
#include <windows.h>

#define PAGESIZE (4 * 1024)

/*************************************************************************
* This function debug memory leaks
*************************************************************************/
static void QueryMemory(void)
{
  byte *base;
  DWORD len, commitsize = 0;
  MEMORY_BASIC_INFORMATION mbi;
  char *State, *Protect;
  OSVERSIONINFO ov;
  char filename[256];


  ov.dwOSVersionInfoSize = sizeof(ov);
  GetVersionEx(&ov);

  if(ov.dwPlatformId == 1)
    printf("Win95\n");
  else
    printf("More than Win95\n");


  for(base = NULL; base < (byte*)(0x7FFF0000); base+=mbi.RegionSize) {

    mbi.State = mbi.Type = mbi.Protect = 0;
    VirtualQuery(base, &mbi, sizeof(mbi));

    if (base == mbi.AllocationBase) {
      len = GetModuleFileName((HMODULE)base, filename, sizeof(filename));
      printf("REGION %p: %s\n", base, len > 0 ? filename : "unknown");
    }

    switch (mbi.State) {
      case MEM_RESERVE:		State = "Reserved";    break;
      case MEM_FREE:		State = "Free    ";    break;
      case MEM_COMMIT:
        switch (mbi.Type) {
          case MEM_IMAGE:	State = "Image   ";   break;
          case MEM_MAPPED:	State = "Mapped  ";   break;
          case MEM_PRIVATE:	State = "Private ";   break;
          default:		State = "Undef   ";
        }
        break;
      default:		        State = "Undef   ";
    }

    if(mbi.State == MEM_COMMIT)
      commitsize += mbi.RegionSize / PAGESIZE;

    switch (mbi.Protect & ~(PAGE_GUARD|PAGE_NOCACHE)) {
      case 0:				Protect = "  F";	break;
      case PAGE_NOACCESS:		Protect = " NA";	break;
      case PAGE_READONLY:		Protect = "  R";	break;
      case PAGE_READWRITE:		Protect = " RW";	break;
      case PAGE_WRITECOPY:		Protect = " WC";	break;
      case PAGE_EXECUTE:		Protect = "  E";	break;
      case PAGE_EXECUTE_READ:		Protect = " ER";	break;
      case PAGE_EXECUTE_READWRITE:	Protect = "ERW";	break;
      case PAGE_EXECUTE_WRITECOPY:	Protect = "EWC";	break;
      default:				Protect = "UND";	break;
    }

    printf("   BLK %p (%7d) %s %s (%x)\n", base, mbi.RegionSize / (4*1024),
          State, Protect, mbi.Protect);
  }
  printf("FULL commitsize = %u pages\n\n", commitsize);
}


int main(int argc, char **argv)
{
  char *ptr, *cptr;

  /* reserve addresses block */
  ptr = (char *) VirtualAlloc (NULL, 500 * PAGESIZE, MEM_RESERVE, PAGE_NOACCESS);

  /* alloc range in address block */
  cptr = (char *) VirtualAlloc (ptr, 100 * PAGESIZE, MEM_COMMIT, PAGE_READWRITE);

  QueryMemory();

  /* free memory */
  VirtualFree(cptr, 100 * PAGESIZE, MEM_DECOMMIT);

  /* free addresses block */
  VirtualFree(ptr, 500 * PAGESIZE, MEM_RELEASE);

  return(0);
}

