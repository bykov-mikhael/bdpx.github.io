
#include <stdio.h>
#include <windows.h>
#include <winnt.h>


LONG MyUnhandledExceptionFilter(EXCEPTION_POINTERS *ExceptionInfo)
{
  DWORD code;

//  code = GetExceptionCode();
  code = 0;
  printf ("code = %u\n", code);
  // exit(666);
//  return (EXCEPTION_EXECUTE_HANDLER);
  return (EXCEPTION_CONTINUE_SEARCH);
}


int main(int argc, char **argv)
{
  int				result;
  LPTOP_LEVEL_EXCEPTION_FILTER	prev;
  DWORD				params[8];

  prev = SetUnhandledExceptionFilter((LPTOP_LEVEL_EXCEPTION_FILTER)MyUnhandledExceptionFilter);

  params[0] = 0;
  params[1] = 1;
  params[2] = 2;
  params[3] = 3;
  RaiseException(1000, EXCEPTION_NONCONTINUABLE, 4, params);

  printf("after exception\n");
  return(0);
}

