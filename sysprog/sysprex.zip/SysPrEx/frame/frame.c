
#include <windows.h>
#include <windowsx.h>

static int Mx, My;

static LRESULT CALLBACK
FrameWndProc(HWND hwnd, UINT uMessage, WPARAM wparam, LPARAM lparam)
{
  HDC dc;
  HPEN pen;
  HBRUSH brush;
  PAINTSTRUCT ps;
  char  msg[256];

  switch(uMessage) {

    case WM_CREATE:
      return(0);
    case WM_DESTROY:
      PostMessage(hwnd, WM_QUIT, 0, 0);
      return(0);
    case WM_COMMAND:
      switch (GET_WM_COMMAND_ID(wparam,lparam)) {
        default:
          sprintf(msg, "I retrieve command message %d from menu", (int)GET_WM_COMMAND_ID(wparam,lparam));
          MessageBoxA(hwnd, msg, "command message retrieved", MB_OK);
      }
      return 0;

    case WM_KEYDOWN:
      sprintf(msg, "I press key with virtual code %d", (int)GET_WM_VKEYTOITEM_CODE(wparam,lparam));
      MessageBoxA(hwnd, msg, "Key pressed", MB_OK);
      return(0);

    case WM_MOUSEMOVE:
      dc = GetDC(hwnd);
      MoveToEx(dc, Mx, My, NULL);
      Mx = GET_X_LPARAM(lparam);
      My = GET_Y_LPARAM(lparam);
      LineTo(dc, Mx, My);
      return(0);

    case WM_PAINT:
      dc = BeginPaint(hwnd, &ps);
        pen = CreatePen(PS_SOLID, 3, RGB(200,100,100));
        SelectObject(dc, pen);
        LineTo(dc, 50, 80);
        DeleteObject(pen);
        brush = CreateHatchBrush(HS_CROSS,RGB(100,200,100));	
        SelectObject(dc, brush);
        Ellipse(dc, 10, 10, 100, 200);
        DeleteObject(brush);

      EndPaint(hwnd, &ps);

    default:
      return DefWindowProc(hwnd, uMessage, wparam, lparam);
  }
  return 0;
}

static void InitApplication(HINSTANCE hInstance)
{
  HWND		wnd;
  HMENU         menu, popup;
  WNDCLASS      wc;

  wc.style         = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc   = FrameWndProc;
  wc.cbClsExtra    = 0;
  wc.cbWndExtra    = 0;
  wc.hInstance     = hInstance;
  wc.hIcon         = NULL;
  wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
  wc.lpszMenuName  = NULL;
  wc.lpszClassName = "MyClassName";
  RegisterClass(&wc);

  menu = CreateMenu();
  popup = CreatePopupMenu();
  InsertMenu(popup, -1, MF_BYPOSITION|MF_STRING|MF_CHECKED, 1, "cmd1");
  InsertMenu(popup, -1, MF_BYPOSITION|MF_STRING, 2, "cmd2");
  InsertMenu(menu, -1, MF_BYPOSITION|MF_POPUP, (UINT)popup, "popup1");
  popup = CreatePopupMenu();
  InsertMenu(popup, -1, MF_BYPOSITION|MF_STRING, 3, "cmd3");
  InsertMenu(popup, -1, MF_BYPOSITION|MF_SEPARATOR, 0, NULL);
  InsertMenu(popup, -1, MF_BYPOSITION|MF_STRING, 4, "cmd4");
  InsertMenu(menu, -1, MF_BYPOSITION|MF_POPUP, (UINT)popup, "popup2");

  wnd = CreateWindow("MyClassName", "My simple window program", WS_OVERLAPPEDWINDOW,
              50, 50, 400, 300, (HWND)NULL, menu, hInstance, NULL);

  ShowWindow(wnd, SW_SHOW);
  UpdateWindow(wnd);
}

int APIENTRY WinMain(
  HINSTANCE lhInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
  MSG      msg;

  InitApplication(lhInstance);
  while(GetMessage(&msg, NULL, 0, 0)) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  return(msg.wParam);
}
