
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <windows.h>
#include <winsock.h>

#define WM_ACCEPT	(WM_USER+1)
#define WM_READY	(WM_USER+2)

#define MAXBUF		8192
#define PORT		5555

#define THREADNUM	32
#define WAIT_ALL	TRUE
#define WAIT_ANY	FALSE

typedef struct {
	SOCKET		socket;
	SOCKADDR_IN	sockaddr;
	char		*buf;
	char		*method;
	char		*path;
	char		*protocol;
	char		*host;
} http_request;

static HANDLE		thread_handle[THREADNUM];
static HANDLE		thread_event[THREADNUM];
static unsigned		thread_id[THREADNUM];


static void logprintf(const char *fmt, ...)
{
  va_list	args;

  va_start(args, fmt);
  vprintf(fmt, args);
  fflush(stdout);
  va_end(args);
}

static void errexit(const char *fmt, ...)
{
  va_list	args;

  va_start(args, fmt);
  vprintf(fmt, args);
  fflush(stdout);
  va_end(args);
  exit(666);
}


static SOCKET ServerStart(void)
{
  int		i, rc;
  SOCKET	listen_socket;
  SOCKADDR_IN	sin;
  WSADATA	WSAData;

  // Initialize Windows Socket 1.1 or later
  rc = WSAStartup(MAKEWORD(1,1), &WSAData);
  if (rc != 0) {
    errexit("WSAStartup Error");
  }

  listen_socket = socket(AF_INET, SOCK_STREAM, 0);
  if (listen_socket == INVALID_SOCKET) {
    errexit("Socket Error");
  }

  sin.sin_family	= AF_INET;
  sin.sin_addr.s_addr	= INADDR_ANY;
  sin.sin_port		= htons(PORT);

  bind(listen_socket, (LPSOCKADDR)&sin, sizeof(SOCKADDR_IN));
  listen(listen_socket, SOMAXCONN);

//  WSAAsyncSelect(listen_socket, hWnd, WM_ACCEPT, FD_ACCEPT);

  logprintf("Server started: %s, status=%s, maxnum=%d maxudp=%d version=%d highversion=%d",
         WSAData.szDescription, WSAData.szSystemStatus,
         (int)WSAData.iMaxSockets, (int)WSAData.iMaxUdpDg,
         (int)WSAData.wVersion, (int)WSAData.wHighVersion);

  return (listen_socket);
}


/******************************************************************************************
* This function post jpeg image to the user
******************************************************************************************/
static int ParseRequest(http_request *request, const char *str, int maxlen)
{
  int	i, k, n, pos;
  char	prop[256], value[1024];

  /* first string */
  i = 0;
  pos = 0;
  while (str[i] != '\r') {
    value[pos++] = str[i++];
  }
  value[pos] = 0;
  i+=2; // CRLF
  logprintf("firstline: %s\n", value);

  k = 0;
  while (!isspace(value[k])) k++;
  value[k] = 0;
  k+=2;
//  request->method = value;
  logprintf("method: %s\n", value);

  n = k;
  while (!isspace(value[k])) k++;
  value[k] = 0;
  k+=1;
  logprintf("path: %s\n", value+n);
  logprintf("protocol: %s\n", value+k);

  while (i < maxlen) {
    if (str[i] == '\r' && str[i+1] == '\n') {
      i += 2;
      break;
    }
    pos = 0;
    while (str[i] != ':' &&  i < maxlen) {
      prop[pos++] = str[i++];
    }
    prop[pos] = 0;
    i+=2; // :SP

    pos = 0;
    while (str[i] != '\r' && i < maxlen) {
      value[pos++] = str[i++];
    }
    value[pos] = 0;
    i+=2; // CRLF
    logprintf("\t%s: %s\n", prop, value);
  }

  logprintf("data: %s\n", str+i);

  while (i < maxlen) {
    pos = 0;
    while (str[i] != '=' && i < maxlen) {
      prop[pos++] = str[i++];
    }
    prop[pos] = 0;
    i++;

    pos = 0;
    while (str[i] != '&' && i < maxlen) {
      value[pos++] = str[i++];
    }
    value[pos] = 0;
    i++;
    logprintf("\t%s: %s\n", prop, value);
  }
  logprintf("end submission\n\n");

  return 0;
}


/******************************************************************************************
* This function post jpeg image to the user
******************************************************************************************/
static void send_jpeg(SOCKET socket)
{
  int		len;
  FILE		*fp;
  char		*filebuf;

  static const char image_resp[] =
	"HTTP/1.1 200 Accept\r\n"
	"Content-Type: image/jpeg\r\n"
	"\r\n";

  static const char forbidden_resp[] =
	"HTTP/1.1 404 File not found\r\n"
	"Content-Type: text/plain\r\n"
	"\r\n"
	"���� � ����������� �����������\r\n";


  /* COMANDANTE CHE GUEVARA */
  fp = fopen("che.jpg", "rb");
  if (fp != NULL) {
    fseek(fp, 0, SEEK_END);
    len = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    filebuf = (char *) malloc (len);
    if (filebuf != NULL) {
      fread(filebuf, 1, len, fp);
      send(socket, image_resp, sizeof(image_resp)-1, 0);
      send(socket, filebuf, len, 0);
      free(filebuf);
    }
    fclose(fp);
  } else {
    send (socket, forbidden_resp, sizeof(forbidden_resp)-1, 0);
  }
}


/******************************************************************************************
* This function post jpeg image to the user
******************************************************************************************/
static void send_source(SOCKET socket)
{
  int		filelen;
  FILE		*fp;
  char		*filebuf;

  static const char source_resp[] =
	"HTTP/1.1 404 XXX\r\n"
	"Content-Type: text/plain\r\n"
	"\r\n"
	"FORBIDDEN";

  send (socket, source_resp, sizeof(source_resp)-1, 0);

/*
  fp = fopen("mywebapp.c", "rb");
  if (fp != NULL) {
    fseek(fp, 0, SEEK_END);
    filelen = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    filebuf = (char *) malloc (filelen);
    if (filebuf != NULL) {
      fread(filebuf, 1, filelen, fp);
      send(socket, filebuf, filelen, 0);
      free(filebuf);
    }
    fclose(fp);
  }
*/

}

/******************************************************************************************
* This function post html text to the user
******************************************************************************************/
static void send_text(SOCKET socket, char *buff, int len)
{
  int		filelen;
  FILE		*fp;
  char		*filebuf;

  static const char text_resp[] =
	"HTTP/1.1 200 Accept\r\n"
	"Content-Type: text/html\r\n"
	"Connection: close\r\n"
	"\r\n"
	"<html><head>\r\n"
	"<title>Web Application Server answer</title>\r\n"
	"</head><body>\r\n"
	"<h1>Hello world</h1>\r\n"
	"<p>Minimal Web Application Server hosted by BDP.\r\n"
	"<p>Multiple connections, restart, reconnections supported.\r\n"
	"<p>Your request is:<br><font color=red>\r\n"
	"<pre>\r\n";

  static const char final[] =
	"</pre></font>\r\n"
	"<p>Try more requests: "
	"<a href='p1'>anchor</a>\r\n"
	"<a href='p2'>anchor</a>\r\n"
	"<a href='p3'>anchor</a>\r\n"
	"<a href='p4'>anchor</a>\r\n"
	"<a href='p5'>anchor</a>\r\n"
	"<p>Try another request type: <a href='che.jpg'>Che Guevara photo</a>\r\n"
	"<p>View source code: <a href='source.txt'>SOURCE</a>\r\n"
	"<p>Form post example:<br><form action='posted' method='post'>\r\n"
	"Name <input type=text name=name>\r\n"
	"Surname <input type=text name=surname>\r\n"
	"<input type=submit value='post'>\r\n"
	"</form>\r\n"
	"</body></html>\r\n";

  send (socket, text_resp, sizeof(text_resp)-1, 0);
  send (socket, buff, len, 0);
  send (socket, final, sizeof(final)-1, 0);
}


/******************************************************************************************
* This function
******************************************************************************************/
static void ProcessRequest(SOCKET socket, char *buff, int len)
{
  http_request	request;

  static const char source_resp[] =
	"HTTP/1.1 200 Accept\r\n"
	"Content-Type: text/plain\r\n"
	"\r\n"
	"test";

  ParseRequest(&request, buff, len);
  if (strnicmp(buff, "GET /che", sizeof("GET /che")-1) == 0) {
    send_jpeg(socket);
  } else if (strnicmp(buff, "GET /source", sizeof("GET /source")-1) == 0) {
    send_source(socket);
  } else {
    send_text(socket, buff, len);
  }
}


unsigned int __stdcall ServerThread(LPVOID tParam)
{
  MSG		msg;
  SOCKET	server_socket;
  int		rc, len, res, thread_num;
  char		buff[MAXBUF];

  thread_num = (int)tParam;
  logprintf("[%d] started\n", thread_num);
  fflush(stdout);

  PeekMessage(&msg, NULL, WM_USER, WM_USER, PM_NOREMOVE);
  logprintf("[%d] now ready: %u\n", thread_num, thread_id[thread_num]);
  SetEvent(thread_event[thread_num]);

  /* infinite message loop */
  for(;;) {
    rc = GetMessage(&msg, NULL, 0, 0);
    if (rc == 0 || rc == -1)
      break;

    switch (msg.message) {
      case WM_ACCEPT:
        ResetEvent(thread_event[thread_num]);
        server_socket = (SOCKET)msg.lParam;
        logprintf("[%d] read from socket: %u\n", thread_num, server_socket);
        len = recv(server_socket, buff, MAXBUF, 0);
        buff[len] = 0;
        ProcessRequest(server_socket, buff, len);
        closesocket(server_socket);
        logprintf("[%d] is free\n", thread_num);
//        Sleep(1000);
        SetEvent(thread_event[thread_num]);
        break;
      case WM_READY:
        ResetEvent(thread_event[thread_num]);
        SetEvent(thread_event[thread_num]);
        break;
      default:
        break;
    }
  }

  SetEvent(thread_event[thread_num]);
  return 0;
}


int main(int argc, char **argv)
{
  int		i, rc, id;
  SOCKET	listen_socket, server_socket;
  SOCKADDR_IN	server_addr, temp_addr;
  int		accepted_len = sizeof(temp_addr);
  char		buf[64];

  listen_socket = ServerStart();

  for (i=0; i<THREADNUM; i++) {
    sprintf(buf, "event_%d", i);
    thread_event[i] = CreateEvent(NULL, FALSE, FALSE, buf);
  }

  for (i=0; i<THREADNUM; i++) {
    thread_handle[i] = (HANDLE)_beginthreadex(NULL, 0, ServerThread, (void*)i, 0, &thread_id[i]);
 
    if (NULL == thread_handle[i]) {
      logprintf("_beginthread failed with error: %d", GetLastError());
      exit(666);
    } else {
      logprintf("thread created: [%d] handle=%p id=%u\n", i, thread_handle[i], thread_id[i]);
      CloseHandle(thread_handle[i]);
    }
  }

  /* Now all threads is ready to work */
  WaitForMultipleObjects(THREADNUM, thread_event, WAIT_ALL, INFINITE);

  for (i=0; i<THREADNUM; i++) {
    PostThreadMessage(thread_id[i], WM_READY, 0, 0);
  }
  logprintf("Message queueing started\n");

  /* infinite loop */
  for(;;) {
    SOCKADDR peer;
    int      peerlen  = sizeof(peer);

    server_socket = accept(listen_socket, (struct sockaddr *) &temp_addr, (int *)&accepted_len);
    if (server_socket == INVALID_SOCKET)
      break;

    /* what host connected with server? */
    if (0 == getpeername(server_socket, &peer, &peerlen)) {
      logprintf("Connect from %s:%d\n", inet_ntoa(((SOCKADDR_IN *)&peer)->sin_addr), ntohs(((SOCKADDR_IN *)&peer)->sin_port));
    }

    rc = WaitForMultipleObjects(THREADNUM, thread_event, WAIT_ANY, INFINITE);
    id = rc - WAIT_OBJECT_0;
    logprintf("[M]: free is %d\n", id);
    PostThreadMessage(thread_id[id], WM_ACCEPT, (WPARAM)0, (LPARAM)server_socket);
  }

  /* Now all threads are closed */
  WaitForMultipleObjects(THREADNUM, thread_event, WAIT_ALL, INFINITE);
  closesocket(listen_socket);
  WSACleanup();
  logprintf("Server stopped\n");
 
  return 0;
}
