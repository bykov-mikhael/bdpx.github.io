
#include <wchar.h>
#include <stdio.h>
#include <windows.h>


int main(int argc, char **argv)
{
  FILE		*fp;
  int		chr;
  char		str[256];
  wchar_t	buf[256];


  if (argc < 2) {
    printf("Usage %s htmlfile\n", argv[0]);
    return (1);
  }

  fp = fopen(argv[1], "rt");
  if(fp == NULL) {
    printf("Unable open file %s\n", argv[1]);
    return (1);
  }

  while ((chr = fgetc(fp)) != EOF) {
    if (chr < 128) {
      printf("%c", chr);
    } else {
      str[0] = chr;
      str[1] = 0;
      MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, str, 1, buf, sizeof(buf));
      printf("&#%u", buf[0]);
    }
  }

  fclose(fp);
  return (0);
}
