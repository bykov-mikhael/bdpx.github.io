
#define UNICODE
#define _UNICODE

#include <wchar.h>
#include <stdio.h>
#include <iostream.h>

//int wmain (int argc, wchar_t *argv[])

int main(void)
{
  int i;
  wchar_t  str[300];

  for(i=0; i<256; i++) {
    str[i] = 0x0400 + i;
    wcout << str[i];
  }
  str[i] = 0;

  wcout << "abcde";
  wcout << str;

  return 0;
}
