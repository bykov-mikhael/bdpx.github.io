
#define UNICODE
#define _UNICODE

#include <wchar.h>
#include <stdio.h>
#include <windows.h>

#define STRIPE 2048
int main(void)
{
  int i, j;
  wchar_t  str[STRIPE+2], head[40];

  for(i=1; i<65536; i+=STRIPE) {
    for(j=0; j<STRIPE; j++) {
       str[j] = i + j;
    }
    str[STRIPE] = 0;
    wsprintf(head, L"Unicode %d - %d", i, i+STRIPE);
    MessageBoxW(NULL, str, head, MB_OK);
  }

  wprintf(L"%ls\n", str);


  return 0;
}
